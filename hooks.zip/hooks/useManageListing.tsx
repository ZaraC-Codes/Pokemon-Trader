import { OTCListing } from "../types";
import { Dispatch, SetStateAction, useCallback } from "react";
import { useActiveWeb3React } from "./useActiveWeb3React";
import { useWriteContract } from "wagmi";
import useNotification from "../utilities/notificationUtils";
import {
  chainIdToEndpoint,
  chainToConfig,
  otcAddress,
  swapContractConfig,
} from "../config";
import { Options } from "@layerzerolabs/lz-v2-utilities";
import { readContract } from "@wagmi/core";
import { AbiCoder, ZeroHash } from "ethers";
import { useQueryClient } from "@tanstack/react-query";

type ClaimResult = {
  txHash: `0x${string}`;
  receipt: any;
  isSameChain: boolean;
};

type UseManageListingOptions = {
  /** Defaults to true (current behavior). If false, caller can show a reveal UI before closing. */
  closeOnSuccess?: boolean;
  /** Called after the tx is confirmed (receipt available). */
  onClaimed?: (result: ClaimResult) => void | Promise<void>;
};

const txTypes = {
  SEND: 0,
  SEND_ACK: 1,
  SEND_FAIL: 2,
};

const abi = new AbiCoder();

export function useManageListing(
  listing: OTCListing,
  setLoading: Dispatch<SetStateAction<boolean>>,
  onClose: any,
  refetchListings: any,
  collectionOfferNFTID?: number,
  manageOptions?: UseManageListingOptions
) {
  const { account, chainId, publicClient } = useActiveWeb3React();
  const { writeContractAsync } = useWriteContract();
  const { showSuccess, showError } = useNotification();
  const queryClient = useQueryClient();

  const invalidateOwnedNfts = useCallback(() => {
    if (!account) return;

    const a1 = listing.tokenForSale?.contractAddress?.toLowerCase?.();
    const a2 = listing.tokenToReceive?.contractAddress?.toLowerCase?.();

    queryClient.invalidateQueries({
      // `useOwnedNfts` uses queryKey: [account, nftAddress || ZeroAddress, chainId, publicClient]
      // `useOwnedNftIds` uses queryKey: ["ownedNftIds", account, nftAddress || ZeroAddress, chainId, publicClient]
      predicate: (q) => {
        const key = q.queryKey as any[];
        if (!Array.isArray(key) || key.length < 2) return false;

        // Case 1: useOwnedNfts key
        const isOwnedNftsKey = String(key[0]).toLowerCase() === account.toLowerCase();
        if (isOwnedNftsKey) {
          const addr = String(key[1] ?? "").toLowerCase();
          return Boolean((a1 && addr === a1) || (a2 && addr === a2));
        }

        // Case 2: useOwnedNftIds key
        const isOwnedNftIdsKey = String(key[0]) === "ownedNftIds" && String(key[1]).toLowerCase() === account.toLowerCase();
        if (isOwnedNftIdsKey) {
          const addr = String(key[2] ?? "").toLowerCase();
          return Boolean((a1 && addr === a1) || (a2 && addr === a2));
        }

        return false;
      },
    });
  }, [account, listing, queryClient]);

  const claimListing = useCallback(async () => {
    setLoading(true);
    try {
      const claimListingParams = {
        _listingId: listing.listingId,
        destinationEndpoint: chainIdToEndpoint[listing.srcChain],
        tokensForSale: [listing.tokenForSale],
        tokensToReceive: [
          collectionOfferNFTID
            ? { ...listing.tokenToReceive, value: BigInt(collectionOfferNFTID) }
          : listing.tokenToReceive,
        ],
      };
      const isSameChain =
        claimListingParams.destinationEndpoint === chainIdToEndpoint[chainId];
      const lzOptions = Options.newOptions().addExecutorLzReceiveOption(
        1000000,
        0
      );
      const destChainId = listing.srcChain;
      const { nativeFee }: any = isSameChain
        ? { nativeFee: BigInt(0) }
        : await readContract(chainToConfig[destChainId], {
            functionName: "quote",
            address: otcAddress[destChainId] as any,
            abi: swapContractConfig.abi,
            args: [
              chainIdToEndpoint[chainId],
              txTypes.SEND_ACK,
              lzOptions.toHex(),
              abi.encode(
                ["uint256", "address", "address"],
                [0, account, account]
              ),
            ],
          });
      const encodedPayload = isSameChain
        ? "0"
        : await readContract(chainToConfig[chainId], {
            functionName: "getSendParamsEncoded",
            address: otcAddress[chainId] as any,
            abi: swapContractConfig.abi,
            args: [claimListingParams, account, lzOptions.toHex()],
          });
      const srcOptions = Options.newOptions().addExecutorLzReceiveOption(
        1000000,
        nativeFee.toString()
      );
      const srcFee: any = isSameChain
        ? { nativeFee: BigInt(0) }
        : await readContract(chainToConfig[chainId], {
            functionName: "quote",
            address: otcAddress[chainId] as any,
            abi: swapContractConfig.abi,
            args: [
              chainIdToEndpoint[destChainId],
              txTypes.SEND,
              srcOptions.toHex(),
              encodedPayload,
            ],
          });
      const tx = await writeContractAsync({
        abi: swapContractConfig.abi,
        args: [
          srcFee.nativeFee,
          claimListingParams,
          isSameChain ? ZeroHash : srcOptions.toHex(),
          isSameChain ? ZeroHash : lzOptions.toHex(),
        ],
        address: otcAddress[chainId] as any,
        functionName: "claimListing",
        account: account,
        value: isSameChain ? 0 : srcFee.nativeFee + nativeFee + BigInt(2000000),
      });

      const receipt = await publicClient?.waitForTransactionReceipt({ hash: tx });
      showSuccess(
        "Successfully claimed listing, the amount should reflect in your wallet shortly"
      );
      invalidateOwnedNfts();
      refetchListings();

      try {
        await manageOptions?.onClaimed?.({ txHash: tx, receipt, isSameChain });
      } catch (e) {
        // Don't break the happy-path if a reveal callback fails.
        console.warn("onClaimed callback failed:", e);
      }

      if (manageOptions?.closeOnSuccess !== false) {
        onClose();
      }
    } catch (error: any) {
      console.error(error);
      // Check for the specific error signature that indicates the user doesn't meet the marketplace access requirement
      // (historically this was "Clutch Puppies ownership"; now it's HV-MTL ecosystem ownership).
      if (error?.message?.includes('0xf4d678b8')) {
        showError("You must own at least one HV-MTL / HV-MTL Activated / AMPs NFT to trade on this platform");
      } else {
        showError("An error occurred while claiming listing");
      }
    } finally {
      setLoading(false);
    }
  }, [
    listing,
    writeContractAsync,
    setLoading,
    publicClient,
    showSuccess,
    showError,
    collectionOfferNFTID,
    account,
    chainId,
    refetchListings,
    onClose,
    invalidateOwnedNfts,
    manageOptions,
  ]);

  const cancelListing = useCallback(async () => {
    setLoading(true);
    try {
      const tx = await writeContractAsync({
        abi: swapContractConfig.abi,
        args: [listing.listingId],
        address: otcAddress[chainId] as any,
        functionName: "closeListing",
        account: account,
      });

      await publicClient?.waitForTransactionReceipt({ hash: tx });
      showSuccess("Successfully cancelled listing");
      invalidateOwnedNfts();
      refetchListings();
      onClose();
    } catch (error) {
      showError("An error occurred while cancelling your listing");
    } finally {
      setLoading(false);
    }
  }, [
    listing,
    writeContractAsync,
    setLoading,
    publicClient,
    showSuccess,
    showError,
    account,
    chainId,
    refetchListings,
    onClose,
    invalidateOwnedNfts,
  ]);

  return { claimListing, cancelListing };
}
